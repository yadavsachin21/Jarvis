"""
app_lock.py — startup lock for MARK LIV (PIN + face + voice).

Put this file in the project ROOT, next to main.py.  JARVIS shows a lock
window first; nothing else starts until it is unlocked.

One-time setup (run from the project root):
    python app_lock.py set-pin          # choose your password  (required)
    python app_lock.py enroll-face      # optional: register your face
    python app_lock.py enroll-voice     # optional: register your voice
    python app_lock.py policy two       # optional: any | two | all   (see below)
    python app_lock.py status

Policy = how many factors must pass before JARVIS opens:
    any  - one is enough (PIN, or face, or voice)         <- default
    two  - any two factors (e.g. face + voice, PIN + face)
    all  - every factor you have registered

HONEST LIMITS: this keeps casual people out. A photo of you can fool the face
check (no liveness test) and a recording can fool the voice check. The PIN is
the real protection, so use policy "two" if you want it stronger. Someone who
can edit the project files can also remove the lock itself.

Needs no new packages (PyQt6, opencv-python, numpy, sounddevice are already in
requirements.txt). Face lock downloads two small model files (~38 MB) once.
"""
from __future__ import annotations

import argparse
import getpass
import hashlib
import hmac
import importlib.util
import json
import math
import os
import secrets
import sys
import threading
import time
from pathlib import Path

import numpy as np


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent


BASE_DIR   = _base_dir()
CONFIG_DIR = BASE_DIR / "config"
LOCK_FILE  = CONFIG_DIR / "lock.json"
FACE_FILE  = CONFIG_DIR / "faceprint.json"
MODEL_DIR  = CONFIG_DIR / "models"

PIN_MIN_LEN     = 4
PBKDF2_ITERS    = 200_000
FAILS_PER_LOCK  = 5          # after this many wrong tries the lock window pauses
LOCK_STEP_SECS  = 30         # ...for 30 s, then 60 s, 90 s ... (max 10 min)

FACE_THRESHOLD  = 0.40       # cosine similarity; higher = stricter (OpenCV's own: 0.363)
FACE_ENROLL_N   = 10         # face samples saved when registering
_YUNET = ("face_detection_yunet_2023mar.onnx",
          "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx")
_SFACE = ("face_recognition_sface_2021dec.onnx",
          "https://github.com/opencv/opencv_zoo/raw/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx")


# ══ Config file ══════════════════════════════════════════════════════════════
def _load() -> dict:
    try:
        return json.loads(LOCK_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(cfg: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    tmp = LOCK_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    tmp.replace(LOCK_FILE)
    try:
        LOCK_FILE.chmod(0o600)
    except Exception:
        pass


# ══ PIN / password ═══════════════════════════════════════════════════════════
def _hash_pin(pin: str, salt: bytes, iters: int) -> str:
    return hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt, iters).hex()


def set_pin(pin: str) -> None:
    if len(pin) < PIN_MIN_LEN:
        raise ValueError(f"Password must be at least {PIN_MIN_LEN} characters.")
    cfg = _load()
    salt = secrets.token_bytes(16)
    cfg.update({
        "enabled":  True,
        "salt":     salt.hex(),
        "iters":    PBKDF2_ITERS,
        "pin_hash": _hash_pin(pin, salt, PBKDF2_ITERS),
        "fails":    0,
        "locked_until": 0,
    })
    cfg.setdefault("policy", "any")
    _save(cfg)


def check_pin(pin: str) -> bool:
    cfg = _load()
    try:
        salt = bytes.fromhex(cfg["salt"])
        want = cfg["pin_hash"]
        got  = _hash_pin(pin, salt, int(cfg.get("iters", PBKDF2_ITERS)))
    except Exception:
        return False
    return hmac.compare_digest(got, want)


# ══ Wrong-attempt lockout (survives restarts) ════════════════════════════════
def lockout_remaining() -> int:
    return max(0, int(_load().get("locked_until", 0) - time.time()))


def record_failure() -> None:
    cfg = _load()
    cfg["fails"] = int(cfg.get("fails", 0)) + 1
    if cfg["fails"] % FAILS_PER_LOCK == 0:
        pause = min(600, LOCK_STEP_SECS * (cfg["fails"] // FAILS_PER_LOCK))
        cfg["locked_until"] = time.time() + pause
    _save(cfg)


def record_success() -> None:
    cfg = _load()
    cfg["fails"] = 0
    cfg["locked_until"] = 0
    _save(cfg)


# ══ Face factor (OpenCV YuNet + SFace) ═══════════════════════════════════════
def _cv2():
    try:
        import cv2
        return cv2
    except Exception:
        return None


def _model_paths() -> tuple[Path, Path]:
    return MODEL_DIR / _YUNET[0], MODEL_DIR / _SFACE[0]


def _models_present() -> bool:
    # A real model is megabytes; a Git-LFS pointer or error page is a few hundred bytes.
    return all(p.exists() and p.stat().st_size > 50_000 for p in _model_paths())


def _download_models() -> bool:
    import urllib.request
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    for (name, url), path in zip((_YUNET, _SFACE), _model_paths()):
        if path.exists() and path.stat().st_size > 50_000:
            continue
        print(f"  downloading {name} ...")
        try:
            with urllib.request.urlopen(url, timeout=60) as r:
                data = r.read()
        except Exception as e:
            print(f"  could not download {name}: {e}")
            return False
        if len(data) < 50_000:
            print(f"  {name}: unexpected tiny download ({len(data)} bytes)")
            return False
        path.write_bytes(data)
    return _models_present()


def _camera_index() -> int:
    try:
        cfg = json.loads((CONFIG_DIR / "api_keys.json").read_text(encoding="utf-8"))
        return int(cfg.get("camera_index", 0))
    except Exception:
        return 0


def _open_camera(cv2):
    backend = (cv2.CAP_DSHOW if sys.platform == "win32"
               else cv2.CAP_AVFOUNDATION if sys.platform == "darwin"
               else cv2.CAP_ANY)
    cap = cv2.VideoCapture(_camera_index(), backend)
    return cap if cap.isOpened() else None


def _grab_embeddings(want: int, seconds: float) -> tuple[list, str]:
    """-> (list of unit-length 128-d face embeddings, problem text or '')."""
    cv2 = _cv2()
    if cv2 is None or not hasattr(cv2, "FaceRecognizerSF"):
        return [], "OpenCV with face support is not available."
    if not _models_present():
        return [], "Face models are missing (run: python app_lock.py enroll-face)."
    cap = _open_camera(cv2)
    if cap is None:
        return [], "Could not open the camera."
    try:
        yunet, sface = _model_paths()
        det = cv2.FaceDetectorYN.create(str(yunet), "", (320, 320), 0.8, 0.3, 5000)
        rec = cv2.FaceRecognizerSF.create(str(sface), "")
        for _ in range(8):                         # let exposure settle
            cap.read()
        out, saw_face, end = [], False, time.time() + seconds
        while time.time() < end and len(out) < want:
            ok, frame = cap.read()
            if not ok or frame is None:
                continue
            h, w = frame.shape[:2]
            det.setInputSize((w, h))
            _, faces = det.detect(frame)
            if faces is None or len(faces) == 0:
                continue
            saw_face = True
            best = faces[int(np.argmax(faces[:, 2] * faces[:, 3]))]   # largest face
            feat = rec.feature(rec.alignCrop(frame, best)).flatten().astype("float64")
            n = np.linalg.norm(feat)
            if n > 0:
                out.append(feat / n)
            time.sleep(0.25)                       # spread samples over time
        if not out:
            return [], ("Face seen but could not be read." if saw_face
                        else "No face found in front of the camera.")
        return out, ""
    finally:
        cap.release()


def enroll_face() -> str:
    if _cv2() is None:
        return "opencv-python is not installed."
    if not _models_present():
        print("First time: fetching the face models (~38 MB, one time only)...")
        if not _download_models():
            yunet, sface = _model_paths()
            return ("Download failed. Download these two files by hand into "
                    f"{MODEL_DIR}:\n  {_YUNET[1]}\n  {_SFACE[1]}")
    print("Look at the camera. Slowly turn your head a little left and right...")
    embs, problem = _grab_embeddings(FACE_ENROLL_N, 10.0)
    if len(embs) < 6:
        return problem or f"Only {len(embs)} good samples; need at least 6. Better light helps."
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    FACE_FILE.write_text(json.dumps({
        "embeddings": [e.tolist() for e in embs],
        "created": time.strftime("%Y-%m-%d %H:%M"),
    }), encoding="utf-8")
    try:
        FACE_FILE.chmod(0o600)
    except Exception:
        pass
    return f"Face registered ({len(embs)} samples). Test it with: python app_lock.py test-face"


def verify_face() -> tuple[bool, str]:
    try:
        saved = np.array(json.loads(FACE_FILE.read_text(encoding="utf-8"))["embeddings"])
    except Exception:
        return False, "No face is registered."
    embs, problem = _grab_embeddings(5, 4.0)
    if not embs:
        return False, problem
    scores = [float(np.max(saved @ e)) for e in embs]       # best match per frame
    passes = sum(s >= FACE_THRESHOLD for s in scores)
    ok = passes >= max(2, math.ceil(len(scores) / 2))
    return ok, f"face score {max(scores):.2f} (need {FACE_THRESHOLD}), {passes}/{len(scores)} frames"


# ══ Voice factor (re-uses plugins/voice_identity.py) ═════════════════════════
def _voice_plugin():
    p = BASE_DIR / "plugins" / "voice_identity.py"
    if not p.exists():
        return None
    try:
        spec = importlib.util.spec_from_file_location("_lock_voice_identity", p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def enroll_voice() -> str:
    vi = _voice_plugin()
    if vi is None or not vi._SD:
        return "Voice lock needs plugins/voice_identity.py and a working microphone."
    print("After the beep, speak normally for 15 seconds (read anything)...")
    vi._beep()
    audio = vi._record(vi.ENROLL_SECS)
    step = int(vi.CLIP_SECS * vi.SR)
    clips = [f for f in (vi._features(audio[i:i + step])
                         for i in range(0, len(audio) - step + 1, step)) if f]
    if len(clips) < 3:
        return "Not enough speech heard. Speak louder and keep talking, then retry."
    vi._save_print(vi._owner_name(), clips)
    return "Voice registered. Test it with: python app_lock.py test-voice"


def verify_voice() -> tuple[bool, str]:
    vi = _voice_plugin()
    if vi is None or not vi._SD:
        return False, "Voice lock is unavailable (plugin or microphone missing)."
    saved = vi._load_print()
    if not saved:
        return False, "No voice is registered."
    try:
        vi._beep()
        feat = vi._features(vi._record(vi.VERIFY_SECS))
    except Exception as e:
        return False, f"Microphone problem: {e}"
    if feat is None:
        return False, "No speech heard. Say a full sentence after the beep."
    ok, ratio, note = vi._compare(saved, feat)
    return ok, f"voice ratio {ratio:.2f} (limit {vi.RATIO_THRESHOLD}), {note}"


# ══ Which factors exist, and the unlock policy ═══════════════════════════════
def available_factors() -> list[str]:
    factors = ["pin"]
    if FACE_FILE.exists() and _models_present() and _cv2() is not None:
        factors.append("face")
    vi_print = BASE_DIR / "memory" / "voiceprint.json"
    if vi_print.exists() and _voice_plugin() is not None:
        factors.append("voice")
    return factors


def factors_needed(policy: str, factors: list[str]) -> int:
    n = {"any": 1, "two": 2, "all": len(factors)}.get(policy, 1)
    return max(1, min(n, len(factors)))


# ══ Lock window (PyQt6) ══════════════════════════════════════════════════════
def _run_dialog() -> bool:
    from PyQt6.QtCore import Qt, pyqtSignal
    from PyQt6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
                                 QLineEdit, QPushButton, QVBoxLayout)

    app = QApplication.instance() or QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)       # closing the lock must not end the app early

    cfg = _load()
    factors = available_factors()
    need = factors_needed(cfg.get("policy", "any"), factors)

    class LockDialog(QDialog):
        bio_done = pyqtSignal(str, bool, str)   # factor, ok, detail

        def __init__(self):
            super().__init__()
            self.passed: set[str] = set()
            self.busy = False
            self.setWindowTitle("J.A.R.V.I.S — Locked")
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
            self.setModal(True)
            self.setFixedWidth(380)
            self.setStyleSheet("""
                QDialog   { background:#05080f; }
                QLabel    { color:#cfe9f3; }
                QLineEdit { background:#0b1220; color:#e8f6ff; border:1px solid #1d3b52;
                            border-radius:8px; padding:10px; font-size:16px; }
                QLineEdit:focus { border:1px solid #00d4ff; }
                QPushButton { background:#0b1c2c; color:#00d4ff; border:1px solid #00d4ff;
                              border-radius:8px; padding:10px; font-weight:bold; letter-spacing:2px; }
                QPushButton:hover    { background:#00d4ff; color:#05080f; }
                QPushButton:disabled { color:#3b5566; border-color:#1d3b52; background:#0b1220; }
            """)
            lay = QVBoxLayout(self)
            lay.setContentsMargins(30, 28, 30, 24)
            lay.setSpacing(12)

            title = QLabel("J.A.R.V.I.S")
            title.setAlignment(Qt.AlignmentFlag.AlignCenter)
            title.setStyleSheet("font-size:26px; font-weight:bold; letter-spacing:8px; color:#00d4ff;")
            sub = QLabel("SYSTEM LOCKED")
            sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
            sub.setStyleSheet("font-size:11px; letter-spacing:4px; color:#5e7a8c;")
            lay.addWidget(title)
            lay.addWidget(sub)

            self.pin = QLineEdit()
            self.pin.setEchoMode(QLineEdit.EchoMode.Password)
            self.pin.setPlaceholderText("Password / PIN")
            self.pin.returnPressed.connect(self._try_pin)
            lay.addWidget(self.pin)

            self.unlock_btn = QPushButton("UNLOCK")
            self.unlock_btn.clicked.connect(self._try_pin)
            lay.addWidget(self.unlock_btn)

            row = QHBoxLayout()
            self.bio_btns: dict[str, QPushButton] = {}
            for f, label in (("face", "FACE"), ("voice", "VOICE")):
                if f in factors:
                    b = QPushButton(label)
                    b.clicked.connect(lambda _=False, name=f: self._try_bio(name))
                    row.addWidget(b)
                    self.bio_btns[f] = b
            if self.bio_btns:
                lay.addLayout(row)

            self.chips = QLabel()
            self.chips.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.status = QLabel("")
            self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.status.setWordWrap(True)
            self.status.setStyleSheet("color:#8fb3c7; font-size:12px;")
            lay.addWidget(self.chips)
            lay.addWidget(self.status)

            self.bio_done.connect(self._on_bio_done)
            self._refresh_chips()
            self._say(self._need_text())
            self.pin.setFocus()

        # ── helpers ──────────────────────────────────────────────────────
        def _need_text(self) -> str:
            return ("Enter your password." if need == 1
                    else f"{need} checks needed: pass any {need} of {', '.join(factors).upper()}.")

        def _say(self, text: str, bad: bool = False) -> None:
            self.status.setStyleSheet(
                f"color:{'#ff6b6b' if bad else '#8fb3c7'}; font-size:12px;")
            self.status.setText(text)

        def _refresh_chips(self) -> None:
            self.chips.setText("   ".join(
                f"{'✓' if f in self.passed else '·'} {f.upper()}" for f in factors))

        def _set_busy(self, busy: bool) -> None:
            self.busy = busy
            for b in self.bio_btns.values():
                b.setEnabled(not busy)
            self.unlock_btn.setEnabled(not busy)

        def _blocked(self) -> bool:
            left = lockout_remaining()
            if left > 0:
                self._say(f"Too many wrong attempts. Try again in {left} s.", bad=True)
                return True
            return self.busy

        def _check_done(self) -> None:
            if len(self.passed) >= need:
                record_success()
                self.accept()
            else:
                self._say(f"{len(self.passed)}/{need} checks passed. Use another method.")

        def _fail(self, text: str) -> None:
            record_failure()
            left = lockout_remaining()
            self._say(text + (f"  Locked for {left} s." if left else ""), bad=True)

        # ── PIN ──────────────────────────────────────────────────────────
        def _try_pin(self) -> None:
            if self._blocked():
                return
            entered = self.pin.text()
            self.pin.clear()
            if "pin" in self.passed:
                return
            if check_pin(entered):
                self.passed.add("pin")
                self._refresh_chips()
                self._check_done()
            else:
                self._fail("Wrong password.")

        # ── Face / voice (run off the UI thread; they block) ─────────────
        def _try_bio(self, factor: str) -> None:
            if self._blocked() or factor in self.passed:
                return
            self._set_busy(True)
            self._say("Look at the camera..." if factor == "face"
                      else "Say a full sentence after the beep...")

            def work():
                try:
                    ok, detail = verify_face() if factor == "face" else verify_voice()
                except Exception as e:
                    ok, detail = False, f"error: {e}"
                self.bio_done.emit(factor, ok, detail)

            threading.Thread(target=work, daemon=True).start()

        def _on_bio_done(self, factor: str, ok: bool, detail: str) -> None:
            print(f"[Lock] {factor}: {'OK' if ok else 'FAILED'} — {detail}")
            self._set_busy(False)
            if ok:
                self.passed.add(factor)
                self._refresh_chips()
                self._check_done()
            else:
                self._fail(f"{factor.upper()} did not match.")

    dlg = LockDialog()
    accepted = dlg.exec() == QDialog.DialogCode.Accepted
    app.setQuitOnLastWindowClosed(True)
    return accepted


def require_unlock() -> bool:
    """Call at the very top of main(). True = go ahead, False = stay closed."""
    cfg = _load()
    if not cfg.get("pin_hash"):
        print("[Lock] No password set yet — lock is OFF. Run:  python app_lock.py set-pin")
        return True
    if not cfg.get("enabled", True):
        return True
    return _run_dialog()


# ══ Command line ═════════════════════════════════════════════════════════════
def _cli() -> None:
    p = argparse.ArgumentParser(description="MARK LIV startup lock")
    p.add_argument("cmd", choices=["set-pin", "enroll-face", "enroll-voice", "test-face",
                                   "test-voice", "policy", "status", "enable", "disable",
                                   "reset"])
    p.add_argument("value", nargs="?", help="for 'policy': any | two | all")
    a = p.parse_args()

    if a.cmd == "set-pin":
        if LOCK_FILE.exists() and _load().get("pin_hash"):
            if not check_pin(getpass.getpass("Current password: ")):
                sys.exit("Wrong current password.")
        pin = getpass.getpass(f"New password (min {PIN_MIN_LEN} chars): ")
        if pin != getpass.getpass("Repeat it: "):
            sys.exit("Passwords did not match.")
        try:
            set_pin(pin)
        except ValueError as e:
            sys.exit(str(e))
        print("Password saved. The lock is ON the next time you start JARVIS.")
    elif a.cmd == "enroll-face":
        print(enroll_face())
    elif a.cmd == "enroll-voice":
        print(enroll_voice())
    elif a.cmd == "test-face":
        ok, d = verify_face(); print("MATCH" if ok else "NO MATCH", "-", d)
    elif a.cmd == "test-voice":
        ok, d = verify_voice(); print("MATCH" if ok else "NO MATCH", "-", d)
    elif a.cmd == "policy":
        if a.value not in ("any", "two", "all"):
            sys.exit("Use: python app_lock.py policy any|two|all")
        cfg = _load(); cfg["policy"] = a.value; _save(cfg)
        print(f"Policy set to '{a.value}'.")
    elif a.cmd in ("enable", "disable"):
        cfg = _load(); cfg["enabled"] = (a.cmd == "enable"); _save(cfg)
        print("Lock enabled." if cfg["enabled"] else "Lock disabled.")
    elif a.cmd == "reset":
        for f in (LOCK_FILE, FACE_FILE, BASE_DIR / "memory" / "voiceprint.json"):
            f.unlink(missing_ok=True)
        print("Password, face data and voice data deleted. The lock is now OFF.")
    else:  # status
        cfg, f = _load(), available_factors()
        print(f"Password set : {bool(cfg.get('pin_hash'))}")
        print(f"Lock enabled : {cfg.get('enabled', True)}")
        print(f"Policy       : {cfg.get('policy', 'any')}  (needs {factors_needed(cfg.get('policy', 'any'), f)} of {f})")
        print(f"Face ready   : {'face' in f}   (models present: {_models_present()})")
        print(f"Voice ready  : {'voice' in f}")
        print(f"Wrong tries  : {cfg.get('fails', 0)}   locked for {lockout_remaining()} s")


if __name__ == "__main__":
    _cli()
