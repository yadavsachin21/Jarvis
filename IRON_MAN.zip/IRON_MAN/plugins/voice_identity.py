"""
voice_identity — JARVIS plugin: "Main kaun hu?"

Recognises the OWNER's voice from a voiceprint recorded once ("register my voice").
  * owner asks "who am I"   -> JARVIS says they are the owner
  * someone else asks       -> JARVIS says "Aap <owner> nahi ho"

Needs NO extra install: MFCC + pitch features are computed with numpy only
(numpy and sounddevice are already in requirements.txt).

Put this file in the plugins/ folder. Nothing else needs to change.
The voiceprint is saved to memory/voiceprint.json  (add it to .gitignore!).

NOTE: this is a lightweight voice match for a demo, not real security.
Never use it to unlock dangerous actions (shutdown, delete files, ...).
"""
import json
import time
from pathlib import Path

import numpy as np

try:
    import sounddevice as sd
    _SD = True
except (ImportError, OSError):      # OSError: PortAudio library missing
    _SD = False

SR              = 16000
ENROLL_SECS     = 15        # how long the owner speaks when registering
VERIFY_SECS     = 4         # how long we listen when asked "who am I"
CLIP_SECS       = 3.0       # enrollment is cut into clips of this length
RATIO_THRESHOLD = 2.2       # lower = stricter.  TUNE this (see console output)
PITCH_TOL_OCT   = 0.30      # max pitch difference in octaves (~3.6 semitones)
DEFAULT_OWNER   = "Sachin Yadav"

BASE_DIR   = Path(__file__).resolve().parent.parent
PRINT_FILE = BASE_DIR / "memory" / "voiceprint.json"

PLUGIN = {
    "name": "voice_identity",
    "description": (
        "Recognises the owner by VOICE. ALWAYS call this tool, immediately and "
        "without speaking first, whenever the user asks who they are or asks to "
        "be recognised: 'main kaun hu', 'mujhe pehchano', 'who am I', 'do you "
        "know me', 'am I Sachin'. NEVER answer such a question from memory, "
        "because it may be a different person speaking. Also use it with "
        "action='enroll' when the user says 'register my voice' / 'meri awaaz "
        "register karo', and action='clear' to delete the saved voiceprint."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "whoami (default) | enroll | clear",
            },
        },
        "required": [],
    },
}


# ── Owner name & mic helpers ─────────────────────────────────────────────────
def _owner_name() -> str:
    try:
        from memory.memory_manager import load_memory
        v = load_memory().get("identity", {}).get("name", {})
        name = v.get("value") if isinstance(v, dict) else v
        if name and isinstance(name, str):
            return name.strip()
    except Exception:
        pass
    return DEFAULT_OWNER


def _input_device():
    """Use the mic chosen in the app's settings, else the system default."""
    try:
        from memory.config_manager import get_input_device
        want = get_input_device()
        if want:
            for i, d in enumerate(sd.query_devices()):
                if d["name"] == want and d["max_input_channels"] > 0:
                    return i
    except Exception:
        pass
    return None


def _beep() -> None:
    try:
        t = np.arange(int(SR * 0.15)) / SR
        sd.play((0.25 * np.sin(2 * np.pi * 880 * t)).astype("float32"), SR)
        sd.wait()
    except Exception:
        pass


def _record(seconds: float) -> np.ndarray:
    audio = sd.rec(int(seconds * SR), samplerate=SR, channels=1,
                   dtype="float32", device=_input_device())
    sd.wait()
    return audio[:, 0]


# ── Feature extraction (MFCC + pitch, numpy only) ────────────────────────────
_FLEN, _HOP, _NFFT, _NFILT, _NCEPS = 400, 160, 512, 26, 20


def _mel_filterbank() -> np.ndarray:
    hz2mel = lambda f: 2595 * np.log10(1 + f / 700)
    mel2hz = lambda m: 700 * (10 ** (m / 2595) - 1)
    pts  = mel2hz(np.linspace(hz2mel(80), hz2mel(7600), _NFILT + 2))
    bins = np.floor((_NFFT + 1) * pts / SR).astype(int)
    fb = np.zeros((_NFILT, _NFFT // 2 + 1))
    for i in range(1, _NFILT + 1):
        l, c, r = bins[i - 1], bins[i], bins[i + 1]
        c = max(c, l + 1)
        r = max(r, c + 1)
        fb[i - 1, l:c] = (np.arange(l, c) - l) / (c - l)
        fb[i - 1, c:r] = (r - np.arange(c, r)) / (r - c)
    return fb


def _dct_matrix() -> np.ndarray:
    n = np.arange(_NFILT)
    k = np.arange(_NCEPS)[:, None]
    return np.cos(np.pi * k * (2 * n + 1) / (2 * _NFILT)) * np.sqrt(2 / _NFILT)


_FB, _DCT = _mel_filterbank(), _dct_matrix()


def _f0_of(frame: np.ndarray):
    f = frame - frame.mean()
    ac = np.fft.irfft(np.abs(np.fft.rfft(f, 1024)) ** 2)[:_FLEN]
    if ac[0] <= 1e-9:
        return None
    lo, hi = int(SR / 400), int(SR / 70)
    lag = lo + int(np.argmax(ac[lo:hi]))
    return SR / lag if ac[lag] / ac[0] > 0.3 else None


def _features(x: np.ndarray):
    """-> {'vec': 38 numbers, 'f0': Hz or None}, or None if too little speech."""
    x = np.asarray(x, dtype=np.float64)
    if len(x) < _FLEN * 3:
        return None
    x = x - x.mean()
    if np.max(np.abs(x)) < 0.02:                            # room is silent / mic muted
        return None
    x = x / (np.max(np.abs(x)) + 1e-9)
    x = np.append(x[0], x[1:] - 0.97 * x[:-1])             # pre-emphasis

    n = 1 + (len(x) - _FLEN) // _HOP
    idx = np.arange(_FLEN)[None, :] + _HOP * np.arange(n)[:, None]
    frames = x[idx] * np.hamming(_FLEN)

    energy = np.log(np.sum(frames ** 2, axis=1) + 1e-10)
    if energy.max() - np.percentile(energy, 10) < 3.0:      # flat noise, no speech
        return None
    frames = frames[energy > energy.max() - 9.0]            # keep speech only
    if len(frames) < 40:                                    # < 0.4 s of speech
        return None

    power = np.abs(np.fft.rfft(frames, _NFFT)) ** 2 / _NFFT
    ceps  = np.log(power @ _FB.T + 1e-10) @ _DCT.T
    ceps  = ceps[:, 1:]                                     # drop c0 (loudness)
    vec   = np.concatenate([ceps.mean(0), ceps.std(0)])

    loud = frames[np.argsort(-np.sum(frames ** 2, axis=1))[:60]]
    f0s  = [f for f in (_f0_of(fr) for fr in loud) if f]
    return {"vec": vec, "f0": float(np.median(f0s)) if len(f0s) >= 8 else None}


# ── Voiceprint storage & comparison ──────────────────────────────────────────
def _save_print(owner: str, clips: list) -> None:
    f0s = [c["f0"] for c in clips if c["f0"]]
    PRINT_FILE.parent.mkdir(parents=True, exist_ok=True)
    PRINT_FILE.write_text(json.dumps({
        "owner":   owner,
        "vecs":    [c["vec"].tolist() for c in clips],
        "f0":      float(np.median(f0s)) if f0s else None,
        "created": time.strftime("%Y-%m-%d %H:%M"),
    }), encoding="utf-8")


def _load_print():
    try:
        return json.loads(PRINT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def _compare(saved: dict, feat: dict) -> tuple[bool, float, str]:
    """-> (is_owner, distance_ratio, pitch_note). Lower ratio = closer match."""
    V = np.array(saved["vecs"])
    centre = V.mean(0)
    radius = max(float(np.mean(np.linalg.norm(V - centre, axis=1))),
                 0.06 * float(np.linalg.norm(centre)))      # floor: avoid ratio blow-up
    ratio = float(np.linalg.norm(feat["vec"] - centre)) / radius

    pitch_ok, note = True, "pitch n/a"
    if saved.get("f0") and feat.get("f0"):
        diff = abs(float(np.log2(feat["f0"] / saved["f0"])))
        pitch_ok, note = diff <= PITCH_TOL_OCT, f"pitch diff {diff:.2f} oct"
    return (ratio <= RATIO_THRESHOLD and pitch_ok), ratio, note


# ── Plugin entry point ───────────────────────────────────────────────────────
def _log(player, text: str) -> None:
    print(f"[VoiceID] {text}")
    if player:
        try:
            player.write_log(f"JARVIS: {text}")
        except Exception:
            pass


def run(parameters: dict, player=None, session_memory=None) -> str:
    try:
        action = ((parameters or {}).get("action") or "whoami").lower().strip()
        owner  = _owner_name()
        first  = owner.split()[0]

        if action == "clear":
            PRINT_FILE.unlink(missing_ok=True)
            return "VOICEPRINT_DELETED. Tell the user the saved voiceprint was removed."

        if not _SD:
            return "sounddevice is not installed, so I cannot listen. Run: pip install sounddevice"

        if action == "enroll":
            _log(player, "Registering voice: speak normally for 15 seconds after the beep.")
            _beep()
            audio = _record(ENROLL_SECS)
            step  = int(CLIP_SECS * SR)
            clips = [f for f in (_features(audio[i:i + step])
                                 for i in range(0, len(audio) - step + 1, step)) if f]
            if len(clips) < 3:
                return ("NOT_ENOUGH_SPEECH. Ask the user to speak louder and "
                        "continuously for the full 15 seconds, then try again.")
            _save_print(owner, clips)
            _log(player, f"Voiceprint saved ({len(clips)} clips).")
            return (f"VOICE_ENROLLED for {owner}. Tell the user in their language "
                    "that their voice has been registered.")

        # default: whoami
        saved = _load_print()
        if not saved:
            return ("NO_VOICEPRINT. Tell the user to first say 'register my voice' "
                    "so I can learn it.")

        _log(player, "Listening: say a sentence after the beep.")
        _beep()
        feat = _features(_record(VERIFY_SECS))
        if feat is None:
            return ("NO_SPEECH_HEARD. Ask the user to say a full sentence right "
                    "after the beep and try again.")

        ok, ratio, note = _compare(saved, feat)
        _log(player, f"ratio={ratio:.2f} (limit {RATIO_THRESHOLD}), {note} -> "
                     f"{'MATCH' if ok else 'NO MATCH'}")
        if ok:
            return (f"VOICE_MATCH. The speaker is {owner}. Tell them clearly in "
                    f"their language: you are {owner}.")
        return (f"VOICE_MISMATCH. This voice is NOT {owner}. Do not guess who it "
                f"is. Tell them clearly in their language: 'Aap {first} nahi ho.'")

    except Exception as e:                                  # never raise from a plugin
        return f"Sir, voice_identity failed: {e}"
